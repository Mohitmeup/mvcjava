package com.cg.dw.controller;

import java.math.BigInteger;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

@Scope("session")
public class NewDebitSession {
	private BigInteger accNo;

	@RequestMapping(value = "/acc", method = RequestMethod.GET)
	public String accounts() {
		//call acc verify methods here
		return "accountPage";
	}

	@RequestMapping(value = "/unm", method = RequestMethod.POST)
	public ModelAndView changeUserName(@RequestParam("unm") BigInteger unm) {
		this.accNo = unm;
		String msg = "UserName is " + this.accNo;
		return new ModelAndView("userNamePage", "msg", msg);
	}

}
