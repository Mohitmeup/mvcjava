package com.cg.dw.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DefaultController {

	@RequestMapping({"/","/home"})
	public String showHome(){
		return "homePage";
	}
	
	@RequestMapping("/menu")
	public String showMenu(){
		return "menuPage";
	}
	
	@RequestMapping("/contactUs")
	public ModelAndView showContactUs(){

		ModelAndView mv = new ModelAndView();
		
		mv.addObject("mailId","vamsy.kiran@iiht.com");
		mv.addObject("mobileNumber","9052224753");
		mv.setViewName("contactUsPage");
		
		return mv;
	}

	@RequestMapping("/aboutUs")
	public ModelAndView showAboutUs(){
List<String> credits= new ArrayList<>();
credits.add("Laima");
credits.add("Shubham");

		ModelAndView mv = new ModelAndView();
	
		mv.addObject("credits",credits);
		mv.setViewName("aboutUsPage");
		
		return mv;
	}
}
