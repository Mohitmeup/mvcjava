package com.cg.dw.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller

@Scope("session")
public class SessionDemo {
	private String userName = "somebody";

	@RequestMapping(value = "/unm", method = RequestMethod.GET)
	public String showInputUserName() {
		return "userNamePage";
	}

	@RequestMapping(value = "/unm", method = RequestMethod.POST)
	public ModelAndView changeUserName(@RequestParam("unm") String unm) {
		this.userName = unm;
		String msg = "UserName is " + this.userName;
		return new ModelAndView("userNamePage", "msg", msg);
	}

	@RequestMapping(value = "/getLen", method = RequestMethod.GET)
	public ModelAndView showLength() {
		String msg = "Length of " + this.userName + " is " + this.userName.length();
		return new ModelAndView("userNamePage", "msg", msg);
	}

	@RequestMapping(value = "/getUpperCase", method = RequestMethod.GET)
	public ModelAndView showUpperCase() {
		String msg = "UpperCase of " + this.userName + " is " + this.userName.toUpperCase();
		return new ModelAndView("userNamePage", "msg", msg);
	}
}
