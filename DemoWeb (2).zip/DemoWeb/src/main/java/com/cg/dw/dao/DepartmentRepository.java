package com.cg.dw.dao;

import java.util.List;

import com.cg.dw.model.Department;

public interface DepartmentRepository {
	Department add(Department dept);
	Department save(Department dept);
	Department findById(Long deptId);
	List<Department> findAll();
	List<Department> findAllByName(String dName);
}
